import os
import argparse
from tqdm import tqdm
import pandas as pd
import joblib
import glob
from collections import OrderedDict
import torch
import torch.backends.cudnn as cudnn
import torch.optim as optim
import torchvision.transforms as transforms
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from Networks.network import MODEL as net
from losses import ir_loss, vi_loss, ssim_loss, gra_loss
import clip
from PIL import Image
import torchvision
import torch.nn.functional as F

device = torch.device('cuda:0')
use_gpu = torch.cuda.is_available()
# evice = "cuda" if torch.cuda.is_available() else "cpu"
c_model, preprocess = clip.load("ViT-B/32", device=device)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='arch10', help='model name: (default: arch+timestamp)')
    parser.add_argument('--epochs', default=20, type=int)
    parser.add_argument('--batch_size', default=64, type=int)
    parser.add_argument('--lr', '--learning-rate', default=1e-3, type=float)
    parser.add_argument('--betas', default=(0.9, 0.999), type=tuple)
    parser.add_argument('--eps', default=1e-8, type=float)
    parser.add_argument('--weight', default=[1, 1, 10, 100], type=float)
    args = parser.parse_args()
    return args


class GetDataset(Dataset):
    def __init__(self, imageFolderDatasetvi, imageFolderDatasetir, transform=None):
        self.imageFolderDataset_vi = imageFolderDatasetvi
        self.imageFolderDataset_ir = imageFolderDatasetir
        self.transform = transform

    def __getitem__(self, index):
        ir = self.imageFolderDataset_ir[index]
        vi = self.imageFolderDataset_vi[index]

        ir = Image.open(ir).convert('L')
        vi = Image.open(vi).convert('L')
       
        if self.transform is not None:
            tran = transforms.ToTensor()
            ir = tran(ir)
            vi = tran(vi)
            input = torch.cat((ir, vi), -3)
            return input, ir, vi

    def __len__(self):
        return len(self.imageFolderDataset_ir)


class AverageMeter(object):

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def train(args, train_loader, model, criterion_ir, criterion_vi, criterion_ssim, criterion_gra, optimizer, epoch,
          scheduler=None):
    losses = AverageMeter()
    losses_ir = AverageMeter()
    losses_vi = AverageMeter()
    losses_ssim = AverageMeter()
    losses_gra = AverageMeter()
    weight = args.weight

    model.train()

    for i, (input, ir, vi) in tqdm(enumerate(train_loader), total=len(train_loader)):
        input = input.cuda()
        ir = ir.cuda()
        vi = vi.cuda()
        out = model(input)
        ir_3 = torch.cat([ir] * 3, dim=1)
        vi_3 = torch.cat([vi] * 3, dim=1)
        out_3 = torch.cat([out] * 3, dim=1)
        ir_3 = F.interpolate(ir_3, size=(224, 224), mode='bilinear', align_corners=True)
        vi_3 = F.interpolate(vi_3, size=(224, 224), mode='bilinear', align_corners=True)
        out_3 = F.interpolate(out_3, size=(224, 224), mode='bilinear', align_corners=True)

        with torch.no_grad():
            ir_features = c_model.encode_image(ir_3)
            vi_features = c_model.encode_image(vi_3)
            out_features = c_model.encode_image(out_3)
        # 定义文本描述a vivid image with detailed background and obvious objects
        #text_description = "a comprehensive image with clearly defined anatomical structures and distinct lesion features"
        #text_description = "a clear image with clearly defined anatomical structures and distinct lesion features"
        text_description = "a vivid image with detailed background and obvious objects"
        # 文本编码
        text_input = torch.tensor(clip.tokenize(text_description)).to(device)
        text_feature = c_model.encode_text(text_input)
        # 计算相似度
        # 计算相似度
        similarities = (text_feature @ out_features.T).squeeze(0)
        similarities = torch.sigmoid(similarities)
        # 计算相似度均值
        loss_clip2 = 1 - similarities.mean()
        loss_clip1 = torch.mean(torch.square(out_features - ir_features)) + torch.mean(
            torch.square(out_features - vi_features))
        loss_ir = weight[0] * criterion_ir(out, ir)
        loss_vi = weight[1] * criterion_vi(out, vi)
        loss_ssim = weight[2] * criterion_ssim(out, ir, vi)
        loss_gra = weight[3] * criterion_gra(out, ir, vi)
        #loss = loss_ir + loss_vi + loss_ssim+ loss_clip2
        loss = loss_ssim + loss_gra + loss_clip1 + loss_clip2
        losses.update(loss.item(), input.size(0))
        losses_ir.update(loss_ir.item(), input.size(0))
        losses_vi.update(loss_vi.item(), input.size(0))
        losses_ssim.update(loss_ssim.item(), input.size(0))
        losses_gra.update(loss_gra.item(), input.size(0))

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    log = OrderedDict([
        ('loss', losses.avg),
        ('loss_ir', losses_ir.avg),
        ('loss_vi', losses_vi.avg),
        ('loss_ssim', losses_ssim.avg),
        ('loss_gra', losses_gra.avg),
    ])

    return log


def main():
    args = parse_args()

    import os

    if not os.path.exists('models/%s' % args.name):
        os.makedirs('models/%s' % args.name)
    else:
        print(f"Directory 'models/{args.name}' already exists.")

    # 确保目录存在
    os.makedirs(os.path.join('models', args.name), exist_ok=True)

    with open(os.path.join('models', args.name, 'args.txt'), 'w') as f:
        for arg in vars(args):
            print('%s: %s' % (arg, getattr(args, arg)), file=f)

    joblib.dump(args, 'models/%s/args.pkl' % args.name)
    cudnn.benchmark = True

    training_dir_ir = "./dataset/ir/"
    folder_dataset_train_ir = glob.glob(os.path.join(training_dir_ir, '*'))

    # 修改这里的目录路径
    training_dir_vi = "./dataset/vi/"
    folder_dataset_train_vi = glob.glob(os.path.join(training_dir_vi, '*'))

    transform_train = transforms.Compose([transforms.ToTensor(),
                                          transforms.Normalize((0.485, 0.456, 0.406),
                                                               (0.229, 0.224, 0.225))
                                          ])

    dataset_train = GetDataset(imageFolderDatasetvi=folder_dataset_train_vi,
                               imageFolderDatasetir=folder_dataset_train_ir,
                               transform=transform_train)
    # dataset_train_vi = GetDataset(imageFolderDataset=folder_dataset_train_vi,
    #                               transform=transform_train)
    train_loader = DataLoader(dataset_train,
                              shuffle=True,
                              batch_size=args.batch_size)
    # train_loader_vi = DataLoader(dataset_train_vi,
    #                              shuffle=True,
    #                              batch_size=args.batch_size)
    model = net(in_channel=2)
    if use_gpu:
        model = model.cuda()
        model.cuda()

    else:
        model = model
    criterion_ir = ir_loss
    criterion_vi = vi_loss
    criterion_ssim = ssim_loss
    criterion_gra = gra_loss
    optimizer = optim.Adam(model.parameters(), lr=args.lr,
                           betas=args.betas, eps=args.eps)
    log = pd.DataFrame(index=[],
                       columns=['epoch',
                                'loss',
                                'loss_ir',
                                'loss_vi',
                                'loss_ssim',
                                'loss_gra',
                                ])

    for epoch in range(args.epochs):

        train_log = train(args, train_loader, model, criterion_ir, criterion_vi, criterion_ssim, criterion_gra,
                          optimizer, epoch)
        tmp = pd.Series([
            epoch + 1,
            train_log['loss'],
            train_log['loss_ir'],
            train_log['loss_vi'],
            train_log['loss_ssim'],
            train_log['loss_gra'],
        ], index=['epoch', 'loss', 'loss_ir', 'loss_vi', 'loss_ssim', 'loss_gra'])

        log = log.append(tmp, ignore_index=True)
        log.to_csv('models/%s/log.csv' % args.name, index=False)

        if (epoch + 1) % 1 == 0:
            torch.save(model.state_dict(), 'models/%s/model_{}.pth'.format(epoch + 1) % args.name)


if __name__ == '__main__':
    main()


