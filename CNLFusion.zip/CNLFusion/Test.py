from PIL import Image
import numpy as np
import os
import torch
import time
import imageio
import torchvision.transforms as transforms
from Networks.network import MODEL as net
import statistics
import glob
#os.environ['CUDA_VISIBLE_DEVICES'] = '0'

device = torch.device('cuda:0')
# 使用 CPU 设备


model = net(in_channel=2)

model_path = "./models/arch/model_30.pth"

model = model.to(device)

model.load_state_dict(torch.load(model_path))

def RGB2YCrCb(input_im):
    im_flat = input_im.transpose(1, 3).transpose(
        1, 2).reshape(-1, 3)  # (nhw,c)
    R = im_flat[:, 0]
    G = im_flat[:, 1]
    B = im_flat[:, 2]
    Y = 0.299 * R + 0.587 * G + 0.114 * B
    Cr = (R - Y) * 0.713 + 0.5
    Cb = (B - Y) * 0.564 + 0.5
    Y = torch.unsqueeze(Y, 1)
    Cr = torch.unsqueeze(Cr, 1)
    Cb = torch.unsqueeze(Cb, 1)
    temp = torch.cat((Y, Cr, Cb), dim=1).to(device)
    out = (
        temp.reshape(
            list(input_im.size())[0],
            list(input_im.size())[2],
            list(input_im.size())[3],
            3,
        )
        .transpose(1, 3)
        .transpose(2, 3)
    )
    return out

def YCrCb2RGB(input_im):
    im_flat = input_im.transpose(1, 3).transpose(1, 2).reshape(-1, 3)
    mat = torch.tensor(
        [[1.0, 1.0, 1.0], [1.403, -0.714, 0.0], [0.0, -0.344, 1.773]]
    ).to(device)
    bias = torch.tensor([0.0 / 255, -0.5, -0.5]).to(device)
    temp = (im_flat + bias).mm(mat).to(device)
    out = (
        temp.reshape(
            list(input_im.size())[0],
            list(input_im.size())[2],
            list(input_im.size())[3],
            3,
        )
        .transpose(1, 3)
        .transpose(2, 3)
    )
    return out

def fusion(ir,vi):
    fuse_time = []

    tran = transforms.ToTensor()
    path1 = ir
    path2 = vi
    img2 = tran(Image.open(vi))

    if img2.size(0)>1:
        img_vi = img2.unsqueeze(0)

        image_vis_ycrcb = RGB2YCrCb(img_vi)
        img_vi = image_vis_ycrcb[:, 0, :, :]
    else:
        img_vi = Image.open(path2).convert('L')
        img_vi = tran(img_vi)
    img_ir = Image.open(path1).convert('L')

    img1_org = tran(img_ir).to(device)
    img2_org = img_vi.to(device)
    #print(img2_org.shape)
    input_img = torch.cat((img1_org, img2_org), 0).unsqueeze(0)

    input_img = input_img.to(device)

    model.eval()
    start = time.time()
    fusion_image = model(input_img)
    end = time.time()
    fuse_time.append(end - start)
   
    if img2.size(0)>1:
        fusion_ycrcb = torch.cat(
            (fusion_image, image_vis_ycrcb[:, 1:2, :, :],
             image_vis_ycrcb[:, 2:, :, :]),
            dim=1,
        )
        fusion_image = YCrCb2RGB(fusion_ycrcb)
        ones = torch.ones_like(fusion_image)
        zeros = torch.zeros_like(fusion_image)
        fusion_image = torch.where(fusion_image > ones, ones, fusion_image)
        fusion_image = torch.where(
            fusion_image < zeros, zeros, fusion_image)
        fused_image = fusion_image.detach().cpu().numpy()
        #print(fused_image.shape)
        fused_image = fused_image.transpose((0, 2, 3, 1))

        fused_image = (fused_image - np.min(fused_image)) / (
                np.max(fused_image) - np.min(fused_image)
        )
    else:
        fused_image = fusion_image.detach().cpu().numpy()

    fused_image = np.uint8(255.0 * fused_image)
    fused_image = fused_image.squeeze()

    save_path = ir.replace('CT','fusion')
    imageio.imwrite(save_path,fused_image )




if __name__ == '__main__':
    training_dir_ir = "./dataset/test/ir/"
    folder_dataset_train_ir = glob.glob(os.path.join(training_dir_ir, '*'))

    # 修改这里的目录路径
    training_dir_vi = "、./dataset/test/vi/"
    folder_dataset_train_vi = glob.glob(os.path.join(training_dir_vi, '*'))
    Time =[]

    for i in range(len(folder_dataset_train_vi)):
        tic = time.time()
        ir = folder_dataset_train_ir[i]
        vi = folder_dataset_train_vi[i]
        fusion(ir,vi)
        toc = time.time()
        Time.append(toc - tic)
    print(np.mean(Time))
